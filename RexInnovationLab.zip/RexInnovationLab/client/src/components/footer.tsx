import { Brain } from "lucide-react";

export default function Footer() {
  const quickLinks = [
    { href: "#home", label: "Home" },
    { href: "#ai-learning", label: "AI Learning" },
    { href: "#competitions", label: "Awards" },
    { href: "#partnerships", label: "Partnerships" },
    { href: "#testimonials", label: "Testimonials" },
    { href: "#about", label: "About Us" },
    { href: "#contact", label: "Contact" },
  ];

  const researchAreas = [
    "Cultural AI Adaptation",
    "Personalized Learning",
    "Educational Technology",
    "Machine Learning"
  ];

  return (
    <footer className="bg-dark-text text-white py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-primary-blue rounded-lg flex items-center justify-center">
                <Brain className="text-white" size={16} />
              </div>
              <div className="text-lg font-bold">Rex Igwe Innovation Lab</div>
            </div>
            <p className="text-gray-300 text-sm">
              Empowering education through culturally adaptive AI systems at Rivers State University.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-gray-300 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Research Areas</h4>
            <ul className="space-y-2 text-sm">
              {researchAreas.map((area) => (
                <li key={area} className="text-gray-300">
                  {area}
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Contact</h4>
            <div className="space-y-2 text-sm text-gray-300">
              <div>Rivers State University</div>
              <div>Port Harcourt, Nigeria</div>
              <div>info@rexigwelab.edu.ng</div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-600 mt-8 pt-8 text-center text-sm text-gray-300">
          <p>&copy; 2024 Rex Igwe Innovation Lab. All rights reserved. | Empowering education through AI innovation.</p>
        </div>
      </div>
    </footer>
  );
}
