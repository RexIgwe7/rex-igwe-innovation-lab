import { GraduationCap, Globe, Rocket } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function MissionOverview() {
  const missionPoints = [
    {
      icon: GraduationCap,
      title: "Personalized Learning",
      description: "AI-driven customization that adapts to individual learning styles and cultural contexts.",
      color: "bg-primary-blue"
    },
    {
      icon: Globe,
      title: "Cultural Adaptation",
      description: "Technology that understands and respects diverse cultural backgrounds and learning preferences.",
      color: "bg-secondary-green"
    },
    {
      icon: Rocket,
      title: "Innovation Hub",
      description: "Leading research and development in educational AI at Rivers State University.",
      color: "bg-accent-orange"
    }
  ];

  return (
    <section className="py-16 bg-neutral-gray">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">Our Mission</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Bridging educational gaps through culturally adaptive AI systems that provide 
            personalized learning experiences tailored to each student's unique background and needs.
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {missionPoints.map((point, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="card-hover text-center h-full">
                <CardContent className="p-6">
                  <div className={`w-16 h-16 ${point.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <point.icon className="text-white" size={24} />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{point.title}</h3>
                  <p className="text-gray-600">{point.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
