import { CheckCircle, Globe, Handshake, Lightbulb, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function AboutSection() {
  const achievements = [
    "Pioneering culturally adaptive AI research",
    "Collaborative partnerships with educational institutions",
    "Focus on inclusive and accessible education technology",
    "Commitment to preserving cultural learning traditions"
  ];

  const visionPoints = [
    {
      icon: Globe,
      title: "Global Reach",
      description: "Expanding our platform to universities worldwide",
      color: "bg-primary-blue"
    },
    {
      icon: Handshake,
      title: "Partnerships",
      description: "Building alliances with educational institutions",
      color: "bg-secondary-green"
    },
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Continuous research and development in AI education",
      color: "bg-accent-orange"
    },
    {
      icon: Heart,
      title: "Impact",
      description: "Creating meaningful change in student outcomes",
      color: "bg-primary-blue"
    }
  ];

  return (
    <section id="about" className="py-16 bg-neutral-gray">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Diverse research team collaborating on AI education technology" 
              className="rounded-2xl shadow-xl w-full h-auto"
            />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-6">About Rex Igwe Innovation Lab</h2>
            <p className="text-lg text-gray-600 mb-6">
              Founded at Rivers State University, our innovation lab is dedicated to developing 
              cutting-edge AI solutions that respect and integrate cultural diversity in education. 
              We believe that effective learning happens when technology adapts to the learner, 
              not the other way around.
            </p>
            
            <div className="space-y-4 mb-8">
              {achievements.map((achievement, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="text-secondary-green" size={20} />
                  <span className="text-gray-700">{achievement}</span>
                </div>
              ))}
            </div>
            
            <Button className="bg-primary-blue hover:bg-blue-700 text-white">
              Learn About Our Research
            </Button>
          </motion.div>
        </div>
        
        {/* Vision and Goals */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-dark-text mb-4">Our Vision for Education Transformation</h3>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We envision a future where AI-powered education is inclusive, culturally sensitive, 
              and accessible to learners from all backgrounds, creating a global learning community 
              that celebrates diversity while ensuring educational excellence.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {visionPoints.map((point, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className={`w-16 h-16 ${point.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <point.icon className="text-white" size={24} />
                </div>
                <h4 className="font-semibold text-lg mb-2">{point.title}</h4>
                <p className="text-gray-600 text-sm">{point.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
