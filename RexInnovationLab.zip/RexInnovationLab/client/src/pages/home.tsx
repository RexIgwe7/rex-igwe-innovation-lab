import { useEffect } from "react";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import MissionOverview from "@/components/mission-overview";
import AILearningSection from "@/components/ai-learning-section";
import CompetitionsSection from "@/components/competitions-section";
import PartnershipsSection from "@/components/partnerships-section";
import TestimonialsSection from "@/components/testimonials-section";
import AboutSection from "@/components/about-section";
import FutureFeatures from "@/components/future-features";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";

export default function Home() {
  useEffect(() => {
    // Smooth scrolling for navigation links
    const handleNavClick = (e: Event) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A' && target.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const targetId = target.getAttribute('href')?.substring(1);
        const targetElement = document.getElementById(targetId || '');
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    };

    document.addEventListener('click', handleNavClick);
    return () => document.removeEventListener('click', handleNavClick);
  }, []);

  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <MissionOverview />
      <AILearningSection />
      <CompetitionsSection />
      <PartnershipsSection />
      <TestimonialsSection />
      <AboutSection />
      <FutureFeatures />
      <ContactSection />
      <Footer />
    </div>
  );
}
