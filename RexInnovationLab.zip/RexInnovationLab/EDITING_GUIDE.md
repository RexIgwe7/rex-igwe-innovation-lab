# Rex Igwe Innovation Lab Website - Editing Guide

This guide will help you easily update and manage the website content after deployment.

## 📁 File Structure

```
shared/
└── constants.ts             # 🔥 GLOBAL SETTINGS (Prize, Contact, Social Media)

client/src/components/
├── hero-section.tsx          # Homepage hero section
├── mission-overview.tsx      # Mission statement and values
├── ai-learning-section.tsx   # AI platform features
├── competitions-section.tsx  # Innovation Award + Global Collaboration
├── partnerships-section.tsx  # Partnership info + Social Media Links
├── testimonials-section.tsx  # Student & Professional Testimonials
├── about-section.tsx         # About the lab
├── contact-section.tsx       # Contact information
├── footer.tsx               # Footer content
└── navigation.tsx           # Navigation menu
```

## ✏️ Common Edits

### 1. Update Competition Prize Amount (GLOBAL EDIT)
**File:** `shared/constants.ts`
**Lines:** Update PRIZE_AMOUNT, PRIZE_CURRENCY, and PRIZE_CURRENCY_CODE
**Note:** This will automatically update the prize display throughout the entire website

### 2. Change Contact Information (GLOBAL EDIT)
**File:** `shared/constants.ts`
**Lines:** Update CONTACT object with new phone numbers and email addresses
**Current Phone Numbers:** 
- +234 (0) 915-581-7412
- +234 (0) 814-230-8987
- +234 (0) 123-456-7890
- +234 (0) 987-654-3210

### 3. Update Partnership Social Media Links (GLOBAL EDIT)
**File:** `shared/constants.ts`
**Lines:** Update PARTNERSHIPS.BRIGHT_LIGHT_ACADEMY object
**Current Links:**
- YouTube: https://youtube.com/@brightlightacademy
- Facebook: https://facebook.com/brightlightacademy  
- Instagram: https://instagram.com/brightlightacademy

### 4. Modify Judging Panel Information
**File:** `client/src/components/competitions-section.tsx`
**Sections:** 
- Chief Judge: "Rex Chukwudum Igwe" section
- Senior Adjudicator: "Lycious Brown" section

### 5. Change Hero Section Text
**File:** `client/src/components/hero-section.tsx`
**Lines:** Update the main heading and description text

### 6. Update Testimonials
**File:** `client/src/components/testimonials-section.tsx`
**Sections:** Modify student feedback and professional endorsements

### 7. Update Global Collaboration Content
**File:** `client/src/components/competitions-section.tsx`
**Section:** Find "Global Collaboration Open" section for international partnership information

## 🎨 Styling Guidelines

### Colors (defined in `client/src/index.css`)
- **Primary Blue:** `hsl(207, 90%, 54%)` - Used for main elements
- **Secondary Green:** `hsl(122, 39%, 49%)` - Used for accent elements
- **Accent Orange:** `hsl(16, 92%, 63%)` - Used for call-to-action buttons

### Common CSS Classes
- `bg-primary-blue` - Blue background
- `bg-secondary-green` - Green background
- `bg-accent-orange` - Orange background
- `text-dark-text` - Dark text color
- `card-hover` - Adds hover effects to cards

## 📱 Responsive Design

The website is fully responsive and uses:
- `md:` prefix for tablet screens
- `lg:` prefix for desktop screens
- Mobile-first approach (base styles apply to mobile)

## 🔧 Making Changes

### For Global Changes (Prize, Contact, Social Media):
1. **Edit `shared/constants.ts`** - This file controls site-wide settings
2. **Update the relevant values** (prize amount, phone numbers, social links)
3. **Save the file** - changes will automatically apply across the entire website

### For Content Changes:
1. **Find the component** you want to edit from the file structure above
2. **Locate the specific text or section** you want to change
3. **Edit the content** while keeping the HTML structure intact
4. **Save the file** - changes will automatically update in the browser

## ⚠️ Important Notes

- Keep all JSX tags properly closed
- Maintain proper indentation
- Don't remove className attributes (they control styling)
- Test on mobile devices after making changes
- Keep social media links updated and working

## 🚀 Adding New Sections

To add new sections:
1. Create a new component file in `client/src/components/`
2. Import and add it to `client/src/pages/home.tsx`
3. Add navigation link in `client/src/components/navigation.tsx`
4. Update footer links in `client/src/components/footer.tsx`

## 📞 Support

For technical support with website updates, contact the development team or refer to the React.js and TypeScript documentation for advanced modifications.