// Global constants for easy editing across the site
export const SITE_CONFIG = {
  // Competition Prize Configuration - Edit these values to update across the entire site
  COMPETITION: {
    PRIZE_AMOUNT: 30000,
    PRIZE_CURRENCY: "₦", // Change to "$", "€", etc. as needed
    PRIZE_CURRENCY_CODE: "NGN", // Change to "USD", "EUR", etc. as needed
    FORMATTED_PRIZE: "₦30,000", // This will be auto-generated but can be manually overridden
  },
  
  // Contact Information - Edit these to update across the site
  CONTACT: {
    EMAIL_PRIMARY: "info@rexigwelab.edu.ng",
    EMAIL_SECONDARY: "rexigwe@rsu.edu.ng",
    PHONE_NUMBERS: [
      "+234 (0) 915-581-7412",
      "+234 (0) 814-230-8987", 
      "+234 (0) 123-456-7890",
      "+234 (0) 987-654-3210"
    ]
  },
  
  // Partnership Links - Edit these to update social media links
  PARTNERSHIPS: {
    BRIGHT_LIGHT_ACADEMY: {
      NAME: "Bright Light Academy",
      YOUTUBE: "https://youtube.com/@brightlightacademy",
      FACEBOOK: "https://facebook.com/brightlightacademy", 
      INSTAGRAM: "https://instagram.com/brightlightacademy"
    }
  }
};

// Helper function to format prize amount
export const getFormattedPrize = () => {
  const { PRIZE_AMOUNT, PRIZE_CURRENCY } = SITE_CONFIG.COMPETITION;
  return `${PRIZE_CURRENCY}${PRIZE_AMOUNT.toLocaleString()}`;
};

// Helper function to get all phone numbers as formatted string
export const getFormattedPhoneNumbers = () => {
  return SITE_CONFIG.CONTACT.PHONE_NUMBERS.join(", ");
};