# Rex Igwe Innovation Lab - Culturally Adaptive AI for Education

## Overview

This is a full-stack web application for the Rex Igwe Innovation Lab at Rivers State University, focused on culturally adaptive AI for education. The application presents the lab's mission, research, and upcoming AI-powered educational tools through a modern, responsive landing page.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Routing**: Wouter for client-side navigation
- **State Management**: React Query for server state management
- **Animations**: Framer Motion for smooth user interactions
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (Active)
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: Built-in session handling with connect-pg-simple
- **Development**: Hot module replacement with Vite integration
- **Storage**: DatabaseStorage class implementing IStorage interface

### Project Structure
```
├── client/          # Frontend React application
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utility functions
├── server/          # Backend Express application
│   ├── routes.ts    # API route definitions
│   ├── storage.ts   # Database abstraction layer
│   └── vite.ts      # Vite integration for development
├── shared/          # Shared code between frontend and backend
│   ├── schema.ts    # Database schema definitions
│   └── constants.ts # Global site configuration (prizes, contact, social media)
└── migrations/      # Database migration files
```

## Key Components

### Frontend Components
- **Navigation**: Responsive navigation bar with smooth scrolling
- **Hero Section**: Landing page with call-to-action buttons
- **Mission Overview**: Lab's core mission and values
- **AI Learning Section**: Features of the AI learning platform
- **Competitions Section**: Rex Igwe Innovation Award with judging panel (Chief Judge: Rex Chukwudum Igwe, Senior Adjudicator: Lycious Brown)
- **Partnerships Section**: Bright Light Academy partnership showcase
- **Testimonials Section**: Student feedback and professional endorsements
- **About Section**: Lab information and achievements
- **Future Features**: Upcoming developments and roadmap
- **Contact Section**: Enhanced contact information and social media links
- **Footer**: Site-wide footer with links and information

### Backend Components
- **Storage Interface**: Abstract storage layer supporting both memory and database storage
- **User Management**: Basic user schema and CRUD operations
- **API Routes**: RESTful API endpoints (currently minimal setup)
- **Session Management**: User session handling with PostgreSQL sessions

### Database Schema
- **Users Table**: Basic user management with username and password fields
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **Migrations**: Database schema versioning and deployment

## Data Flow

### Current Implementation
1. **Static Content**: Landing page renders static content about the lab
2. **Navigation**: Client-side routing between sections using smooth scrolling
3. **Responsive Design**: Mobile-first approach with Tailwind CSS breakpoints
4. **User Interface**: Interactive components using Radix UI primitives
5. **Database**: PostgreSQL database with user management schema (December 2024)
6. **Competitions**: Rex Igwe Innovation Award with full judging panel details
7. **Partnerships**: Enhanced Bright Light Academy partnership information  
8. **Testimonials**: Student and professional feedback sections
9. **Enhanced Contact**: Updated contact information with four phone numbers and email integration
10. **Global Configuration**: Created shared/constants.ts for easy editing of prize amounts, contact info, and social media links
11. **Global Collaboration**: Added international partnership section encouraging worldwide educational collaboration

### Future Data Flow (Planned)
1. **User Registration**: Students and faculty can sign up for beta access
2. **AI Learning Platform**: Personalized learning content based on cultural preferences
3. **Progress Tracking**: Analytics and performance monitoring
4. **Collaborative Features**: Group learning and faculty tools

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React 18+ with TypeScript support
- **UI Framework**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS for utility-first styling
- **Icons**: Lucide React for consistent iconography
- **Animations**: Framer Motion for smooth transitions
- **HTTP Client**: Fetch API with React Query for data fetching

### Backend Dependencies
- **Express.js**: Web application framework
- **Database**: PostgreSQL with Drizzle ORM
- **Session Storage**: connect-pg-simple for PostgreSQL sessions
- **Development Tools**: tsx for TypeScript execution, esbuild for production builds

### Development Dependencies
- **Build Tools**: Vite for development server and build process
- **TypeScript**: Full TypeScript support across the stack
- **Linting**: ESLint configuration for code quality
- **PostCSS**: CSS processing with Tailwind CSS

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot module replacement
- **Database**: Neon Database for development and production
- **Environment Variables**: DATABASE_URL required for database connection

### Production Build
- **Frontend**: Vite builds optimized React application to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Static Assets**: Served directly by Express in production
- **Database Migrations**: Drizzle migrations applied via `db:push` command

### Deployment Requirements
- **Node.js**: ES modules support with Node 18+
- **PostgreSQL**: Compatible database (Neon Database recommended)
- **Environment Variables**: DATABASE_URL for database connectivity
- **Process Management**: PM2 or similar for production process management

### Scripts
- `npm run dev`: Development server with hot reload
- `npm run build`: Production build for both frontend and backend
- `npm run start`: Production server
- `npm run check`: TypeScript type checking
- `npm run db:push`: Deploy database schema changes

The application is designed to be easily deployable on platforms like Replit, Vercel, or traditional hosting providers with minimal configuration required.