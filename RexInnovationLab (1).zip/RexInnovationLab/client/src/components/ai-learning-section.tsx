import { UserCheck, TrendingUp, MessageSquare, Languages, Users, Award } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function AILearningSection() {
  const aiFeatures = [
    {
      icon: UserCheck,
      title: "Cultural Context Analysis",
      description: "Our AI analyzes cultural background, learning preferences, and communication styles to create personalized educational pathways.",
      color: "bg-primary-blue"
    },
    {
      icon: TrendingUp,
      title: "Adaptive Learning Algorithms",
      description: "Dynamic content adjustment based on performance, engagement, and cultural learning patterns to optimize understanding.",
      color: "bg-secondary-green"
    },
    {
      icon: MessageSquare,
      title: "Intelligent Feedback System",
      description: "Real-time, culturally sensitive feedback that encourages growth while respecting individual learning styles.",
      color: "bg-accent-orange"
    }
  ];

  const keyFeatures = [
    {
      icon: Languages,
      title: "Multi-Language Support",
      description: "Learning content available in multiple languages and dialects, preserving cultural linguistic heritage.",
      color: "bg-primary-blue"
    },
    {
      icon: Users,
      title: "Collaborative Learning",
      description: "AI-facilitated group learning that considers cultural collaboration styles and social learning preferences.",
      color: "bg-secondary-green"
    },
    {
      icon: Award,
      title: "Performance Analytics",
      description: "Detailed insights into learning progress with culturally relevant assessment methods and success metrics.",
      color: "bg-accent-orange"
    }
  ];

  return (
    <section id="ai-learning" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">AI Learning Platform</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover how our culturally adaptive AI model transforms education by providing 
            intelligent, personalized learning experiences that respect and incorporate cultural diversity.
          </p>
        </motion.div>

        {/* AI Features Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-dark-text mb-6">How Our AI Works</h3>
            <div className="space-y-6">
              {aiFeatures.map((feature, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className={`w-8 h-8 ${feature.color} rounded-full flex items-center justify-center flex-shrink-0 mt-1`}>
                    <feature.icon className="text-white" size={16} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">{feature.title}</h4>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-primary-blue to-secondary-green rounded-2xl p-8 text-white"
          >
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <h4 className="text-2xl font-bold mb-2">AI Model Dashboard</h4>
              <p className="opacity-90">Real-time learning analytics and cultural adaptation metrics</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white bg-opacity-20 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold">1,247</div>
                <div className="text-sm opacity-90">Active Students</div>
              </div>
              <div className="bg-white bg-opacity-20 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold">89%</div>
                <div className="text-sm opacity-90">Cultural Adaptations</div>
              </div>
            </div>
            
            <div className="text-center">
              <Button className="bg-white text-primary-blue hover:bg-gray-100 font-semibold">
                View AI Demo
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Key Features */}
        <div className="grid md:grid-cols-3 gap-8">
          {keyFeatures.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-neutral-gray card-hover h-full">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mb-4`}>
                    <feature.icon className="text-white" size={20} />
                  </div>
                  <h4 className="text-xl font-semibold mb-3">{feature.title}</h4>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
