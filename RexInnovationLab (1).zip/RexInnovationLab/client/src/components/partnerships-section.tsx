import { Handshake, BookOpen, Lightbulb, Target, Youtube, Facebook, Instagram, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { SITE_CONFIG } from "@shared/constants";

export default function PartnershipsSection() {
  const partnershipBenefits = [
    {
      icon: BookOpen,
      title: "Educational Excellence",
      description: "Advanced AI-powered learning methodologies integrated into curriculum",
      color: "bg-primary-blue"
    },
    {
      icon: Lightbulb,
      title: "Innovation Hub",
      description: "Collaborative research and development in educational technology",
      color: "bg-secondary-green"
    },
    {
      icon: Target,
      title: "Student Success",
      description: "Improved learning outcomes through culturally adaptive AI systems",
      color: "bg-accent-orange"
    }
  ];

  return (
    <section id="partnerships" className="py-16 bg-neutral-gray">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">
            Strategic Partnerships
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Building collaborative relationships with educational institutions to advance 
            AI-powered learning and create meaningful impact in student education and development.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Partnership Spotlight */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card className="bg-white shadow-xl">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary-blue to-secondary-green rounded-xl flex items-center justify-center mr-4">
                    <Handshake className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-dark-text">Bright Light Academy</h3>
                    <p className="text-primary-blue font-semibold">Featured Partnership</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <p className="text-gray-600">
                    Our strategic partnership with Bright Light Academy represents a significant 
                    commitment to educational innovation and excellence. This collaboration with 
                    the Rex Igwe Innovation Lab demonstrates our shared dedication to promoting 
                    educational growth through culturally adaptive AI systems and innovative learning approaches.
                  </p>
                  
                  <div className="bg-neutral-gray rounded-lg p-4">
                    <h4 className="font-semibold mb-2 text-dark-text">Partnership Highlights</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li className="flex items-start">
                        <span className="w-2 h-2 bg-primary-blue rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        AI-powered personalized learning implementation
                      </li>
                      <li className="flex items-start">
                        <span className="w-2 h-2 bg-secondary-green rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        Cultural context integration in curriculum design
                      </li>
                      <li className="flex items-start">
                        <span className="w-2 h-2 bg-accent-orange rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        Student performance analytics and insights
                      </li>
                      <li className="flex items-start">
                        <span className="w-2 h-2 bg-primary-blue rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        Teacher training and AI integration workshops
                      </li>
                    </ul>
                  </div>
                  
                  {/* Social Media Links */}
                  <div className="bg-white rounded-lg p-4">
                    <h4 className="font-semibold mb-3 text-dark-text">Connect with Bright Light Academy</h4>
                    <div className="flex justify-center space-x-4">
                      <a
                        href="https://youtube.com/@brightlightacademy"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-white transition-colors"
                      >
                        <Youtube size={20} />
                      </a>
                      <a
                        href="https://facebook.com/brightlightacademy"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center text-white transition-colors"
                      >
                        <Facebook size={20} />
                      </a>
                      <a
                        href="https://instagram.com/brightlightacademy"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 bg-pink-500 hover:bg-pink-600 rounded-full flex items-center justify-center text-white transition-colors"
                      >
                        <Instagram size={20} />
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <Button className="bg-primary-blue hover:bg-blue-700 text-white flex-1">
                      Learn More
                    </Button>
                    <Button variant="outline" className="flex-1">
                      Partnership Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Partnership Impact */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-primary-blue to-secondary-green rounded-2xl p-8 text-white">
                <h3 className="text-2xl font-bold mb-4">Partnership Impact</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white bg-opacity-20 rounded-lg p-4 text-center">
                    <div className="text-3xl font-bold">500+</div>
                    <div className="text-sm opacity-90">Students Reached</div>
                  </div>
                  <div className="bg-white bg-opacity-20 rounded-lg p-4 text-center">
                    <div className="text-3xl font-bold">25+</div>
                    <div className="text-sm opacity-90">Teachers Trained</div>
                  </div>
                  <div className="bg-white bg-opacity-20 rounded-lg p-4 text-center">
                    <div className="text-3xl font-bold">95%</div>
                    <div className="text-sm opacity-90">Satisfaction Rate</div>
                  </div>
                  <div className="bg-white bg-opacity-20 rounded-lg p-4 text-center">
                    <div className="text-3xl font-bold">12</div>
                    <div className="text-sm opacity-90">Months Active</div>
                  </div>
                </div>
              </div>

              <Card className="bg-white">
                <CardContent className="p-6">
                  <h4 className="text-xl font-semibold mb-4 text-dark-text">
                    Ready to Partner?
                  </h4>
                  <p className="text-gray-600 mb-4">
                    Join our network of educational institutions committed to innovation 
                    and student success through AI-powered learning solutions.
                  </p>
                  <Button className="bg-secondary-green hover:bg-green-700 text-white w-full">
                    Explore Partnership Opportunities
                  </Button>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </div>

        {/* Partnership Benefits */}
        <div className="grid md:grid-cols-3 gap-8">
          {partnershipBenefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white card-hover h-full text-center">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${benefit.color} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                    <benefit.icon className="text-white" size={20} />
                  </div>
                  <h4 className="text-xl font-semibold mb-3">{benefit.title}</h4>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}