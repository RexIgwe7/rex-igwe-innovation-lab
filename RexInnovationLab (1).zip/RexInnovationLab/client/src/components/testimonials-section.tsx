import { Quote, Star, GraduationCap, Users, Briefcase } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

export default function TestimonialsSection() {
  const studentTestimonials = [
    {
      name: "Chioma Okafor",
      role: "Computer Science Student, RSU",
      content: "The AI learning platform has completely transformed how I approach my studies. The culturally adaptive features make complex concepts more relatable and easier to understand.",
      rating: 5,
      avatar: "CO",
      category: "student"
    },
    {
      name: "Emmanuel Dike",
      role: "Secondary School Student",
      content: "Participating in the Rex Igwe Innovation Award opened my eyes to the possibilities of AI in education. The mentorship and resources provided are exceptional.",
      rating: 5,
      avatar: "ED",
      category: "student"
    }
  ];

  const professionalTestimonials = [
    {
      name: "Dr. Sarah Adebayo",
      role: "Faculty of Education, RSU",
      content: "The Rex Igwe Innovation Lab is pioneering a new era of educational technology. Their culturally adaptive AI approach addresses critical gaps in traditional learning methods.",
      rating: 5,
      avatar: "SA",
      category: "faculty"
    },
    {
      name: "Prof. Michael Okonkwo",
      role: "Dean of Computer Science",
      content: "The collaboration between technology and cultural understanding demonstrated by this lab sets a new standard for educational innovation in Nigeria and beyond.",
      rating: 5,
      avatar: "MO",
      category: "faculty"
    }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        size={16}
        className={i < rating ? "text-accent-orange fill-current" : "text-gray-300"}
      />
    ));
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "student":
        return <GraduationCap className="text-primary-blue" size={20} />;
      case "faculty":
        return <Briefcase className="text-secondary-green" size={20} />;
      default:
        return <Users className="text-accent-orange" size={20} />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "student":
        return "bg-primary-blue";
      case "faculty":
        return "bg-secondary-green";
      default:
        return "bg-accent-orange";
    }
  };

  return (
    <section id="testimonials" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">
            What Our Community Says
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Hear from students, faculty, and colleagues about the impact of our 
            culturally adaptive AI initiatives and educational innovations.
          </p>
        </motion.div>

        {/* Student Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <div className="flex items-center mb-6">
            <GraduationCap className="text-primary-blue mr-3" size={24} />
            <h3 className="text-2xl font-bold text-dark-text">Student Feedback</h3>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {studentTestimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="bg-neutral-gray card-hover h-full">
                  <CardContent className="p-6">
                    <div className="flex items-start mb-4">
                      <Quote className="text-primary-blue mr-3 flex-shrink-0" size={20} />
                      <p className="text-gray-600 italic">{testimonial.content}</p>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 ${getCategoryColor(testimonial.category)} rounded-full flex items-center justify-center`}>
                          <span className="text-white font-semibold text-sm">{testimonial.avatar}</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-dark-text">{testimonial.name}</h4>
                          <p className="text-sm text-gray-500">{testimonial.role}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        {renderStars(testimonial.rating)}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Professional Endorsements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-6">
            <Briefcase className="text-secondary-green mr-3" size={24} />
            <h3 className="text-2xl font-bold text-dark-text">Professional Endorsements</h3>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {professionalTestimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.5 + index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="bg-neutral-gray card-hover h-full">
                  <CardContent className="p-6">
                    <div className="flex items-start mb-4">
                      <Quote className="text-secondary-green mr-3 flex-shrink-0" size={20} />
                      <p className="text-gray-600 italic">{testimonial.content}</p>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 ${getCategoryColor(testimonial.category)} rounded-full flex items-center justify-center`}>
                          <span className="text-white font-semibold text-sm">{testimonial.avatar}</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-dark-text">{testimonial.name}</h4>
                          <p className="text-sm text-gray-500">{testimonial.role}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        {renderStars(testimonial.rating)}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Card className="bg-gradient-to-br from-primary-blue to-secondary-green text-white">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Share Your Experience</h3>
              <p className="text-lg mb-6 opacity-90">
                Have you been impacted by our AI educational initiatives? We'd love to hear your story.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-primary-blue hover:bg-gray-100 font-semibold py-3 px-6 rounded-lg transition-colors">
                  Submit Student Feedback
                </button>
                <button className="bg-accent-orange hover:bg-orange-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors">
                  Provide Professional Endorsement
                </button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}