import { Bot, Smartphone, Glasses, Presentation, CheckCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

export default function FutureFeatures() {
  const chatbotFeatures = [
    "24/7 Student Support",
    "Multilingual Communication",
    "Cultural Context Awareness",
    "Intelligent Study Planning"
  ];

  const upcomingFeatures = [
    {
      icon: Smartphone,
      title: "Mobile Learning App",
      description: "Native mobile application for on-the-go learning with offline capabilities and cultural preference sync.",
      color: "bg-secondary-green"
    },
    {
      icon: Glasses,
      title: "VR Learning Experiences",
      description: "Immersive virtual reality educational content that incorporates cultural landmarks and historical contexts.",
      color: "bg-accent-orange"
    },
    {
      icon: Presentation,
      title: "Faculty AI Assistant",
      description: "AI-powered tools for educators to create culturally inclusive lesson plans and assessment methods.",
      color: "bg-primary-blue"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">Coming Soon</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Exciting new features in development to enhance the learning experience and provide 
            even more personalized, culturally adaptive educational support.
          </p>
        </motion.div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-primary-blue to-secondary-green rounded-2xl p-8 text-white"
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center mr-4">
                <Bot size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Interactive AI Chatbot</h3>
                <Badge className="bg-accent-orange text-white mt-1">Coming Q2 2024</Badge>
              </div>
            </div>
            
            <p className="text-lg mb-6 opacity-90">
              An intelligent chatbot that provides instant support, answers questions about coursework, 
              and offers personalized study recommendations based on cultural learning preferences.
            </p>
            
            <div className="space-y-3">
              {chatbotFeatures.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="text-accent-orange" size={16} />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </motion.div>
          
          <div className="space-y-6">
            {upcomingFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="bg-neutral-gray card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className={`w-10 h-10 ${feature.color} rounded-lg flex items-center justify-center mr-3`}>
                        <feature.icon className="text-white" size={20} />
                      </div>
                      <h4 className="text-xl font-semibold">{feature.title}</h4>
                    </div>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
