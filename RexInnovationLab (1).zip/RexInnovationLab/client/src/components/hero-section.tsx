import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section id="home" className="relative pt-16 min-h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Modern university classroom with students using technology" 
          className="w-full h-full object-cover"
        />
        <div className="gradient-overlay absolute inset-0"></div>
      </div>
      
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Empowering Education Through 
            <span className="text-accent-orange"> Culturally Adaptive AI</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed opacity-95">
            Revolutionizing personalized learning experiences for students at Rivers State University 
            and beyond through innovative AI technology that understands and adapts to cultural contexts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="bg-accent-orange hover:bg-orange-600 text-white font-semibold py-4 px-8 rounded-lg shadow-lg transition-all transform hover:scale-105"
            >
              Explore AI Learning Platform
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-2 border-white text-white hover:bg-white hover:text-primary-blue font-semibold py-4 px-8 rounded-lg transition-all"
            >
              Learn More About Our Mission
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
