import { MapPin, Mail, Phone, GraduationCap, Presentation, University } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { SITE_CONFIG } from "@shared/constants";

export default function ContactSection() {
  const contactInfo = [
    {
      icon: MapPin,
      title: "Location",
      content: "Rivers State University\nPort Harcourt, Rivers State, Nigeria",
      color: "bg-primary-blue"
    },
    {
      icon: Mail,
      title: "Email",
      content: "info@rexigwelab.edu.ng\nrexigwe@rsu.edu.ng",
      color: "bg-secondary-green"
    },
    {
      icon: Phone,
      title: "Phone",
      content: "+234 (0) 915-581-7412\n+234 (0) 814-230-8987\n+234 (0) 123-456-7890\n+234 (0) 987-654-3210",
      color: "bg-accent-orange"
    }
  ];

  const engagementOptions = [
    {
      icon: GraduationCap,
      title: "For Students",
      description: "Join our pilot program and be among the first to experience culturally adaptive AI learning.",
      buttonText: "Sign Up for Beta Access",
      buttonColor: "bg-primary-blue hover:bg-blue-700",
      iconColor: "text-primary-blue"
    },
    {
      icon: Presentation,
      title: "For Faculty",
      description: "Collaborate with our research team to integrate AI tools into your curriculum and teaching methods.",
      buttonText: "Explore Partnership",
      buttonColor: "bg-secondary-green hover:bg-green-700",
      iconColor: "text-secondary-green"
    },
    {
      icon: University,
      title: "For Institutions",
      description: "Partner with us to implement culturally adaptive AI solutions across your educational programs.",
      buttonText: "Discuss Integration",
      buttonColor: "bg-accent-orange hover:bg-orange-600",
      iconColor: "text-accent-orange"
    }
  ];

  return (
    <section id="contact" className="py-16 bg-neutral-gray">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">Get Involved</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Join us in revolutionizing education through culturally adaptive AI. Whether you're a student, 
            faculty member, or educational institution, there are many ways to participate in our mission.
          </p>
        </motion.div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-dark-text mb-6">Contact Information</h3>
            
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className={`w-10 h-10 ${info.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <info.icon className="text-white" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">{info.title}</h4>
                    <p className="text-gray-600 whitespace-pre-line">{info.content}</p>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Social Media Links */}
            <div className="mt-8">
              <h4 className="font-semibold text-lg mb-4">Connect With Us</h4>
              <div className="space-y-3">
                <div className="flex space-x-4">
                  <a 
                    href="https://linkedin.com/company/rex-igwe-innovation-lab" 
                    className="w-10 h-10 bg-primary-blue rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors"
                    title="LinkedIn"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://twitter.com/rexigwelab" 
                    className="w-10 h-10 bg-primary-blue rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors"
                    title="Twitter"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://facebook.com/rexigwelab" 
                    className="w-10 h-10 bg-primary-blue rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors"
                    title="Facebook"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://youtube.com/@rexigwelab" 
                    className="w-10 h-10 bg-primary-blue rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors"
                    title="YouTube"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                    </svg>
                  </a>
                </div>
                <p className="text-sm text-gray-500">
                  Follow us for updates on AI research, innovation awards, and educational partnerships.
                </p>
              </div>
            </div>
          </motion.div>
          
          {/* Engagement Options */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-dark-text mb-6">Ways to Engage</h3>
            
            <div className="space-y-6">
              {engagementOptions.map((option, index) => (
                <Card key={index} className="bg-white card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-3">
                      <option.icon className={`${option.iconColor} mr-3`} size={24} />
                      <h4 className="font-semibold text-lg">{option.title}</h4>
                    </div>
                    <p className="text-gray-600 mb-4">{option.description}</p>
                    <Button className={`${option.buttonColor} text-white text-sm`}>
                      {option.buttonText}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
