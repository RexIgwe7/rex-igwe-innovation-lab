import { Trophy, Star, Users, Award, Globe } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { getFormattedPrize } from "@shared/constants";

export default function CompetitionsSection() {
  const competitionFeatures = [
    {
      icon: Trophy,
      title: "Cash Prize",
      description: `${getFormattedPrize()} award for innovative AI solutions`,
      color: "bg-accent-orange"
    },
    {
      icon: Users,
      title: "Open to All",
      description: "Secondary school and university students (RSU students prioritized)",
      color: "bg-primary-blue"
    },
    {
      icon: Star,
      title: "Innovation Focus", 
      description: "AI applications in education and society",
      color: "bg-secondary-green"
    },
    {
      icon: Globe,
      title: "Global Collaboration",
      description: "Open for international students and educational partners",
      color: "bg-accent-orange"
    }
  ];

  return (
    <section id="competitions" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text mb-4">
            Rex Igwe Innovation Award
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Recognizing outstanding innovation in AI applications for education and society. 
            Open to secondary school and university students globally, with priority given to 
            RSU students. We welcome international collaboration and partnerships in advancing 
            educational technology through AI innovation.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Competition Details */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="bg-gradient-to-br from-primary-blue to-secondary-green rounded-2xl p-8 text-white">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center mr-4">
                  <Award size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Innovation Award 2024</h3>
                  <Badge className="bg-accent-orange text-white mt-1">Now Open</Badge>
                </div>
              </div>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between items-center bg-white bg-opacity-20 rounded-lg p-4">
                  <span className="font-semibold">Prize Amount</span>
                  <span className="text-2xl font-bold">{getFormattedPrize()}</span>
                </div>
                <div className="bg-white bg-opacity-20 rounded-lg p-4">
                  <h4 className="font-semibold mb-2">Eligibility</h4>
                  <ul className="text-sm space-y-1 opacity-90">
                    <li>• Secondary school and university students globally</li>
                    <li>• Rivers State University students (prioritized)</li>
                    <li>• International students and educational partners welcome</li>
                    <li>• Individual or team submissions</li>
                  </ul>
                </div>
              </div>
              
              <div className="text-center">
                <Button className="bg-white text-primary-blue hover:bg-gray-100 font-semibold">
                  Apply for Award
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Judging Panel */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Chief Judge */}
            <Card className="bg-neutral-gray">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 bg-primary-blue rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xl font-bold text-white">RI</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-dark-text">Rex Chukwudum Igwe</h3>
                    <p className="text-primary-blue font-semibold mb-2">Chief Judge</p>
                    <p className="text-gray-600 text-sm">
                      Distinguished leader in AI and digital education with extensive experience in 
                      educational technology innovation. Spearheads initiatives that bridge the gap 
                      between artificial intelligence and culturally adaptive learning systems.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Senior Adjudicator */}
            <Card className="bg-neutral-gray">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 bg-secondary-green rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xl font-bold text-white">LB</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-dark-text">Lycious Brown</h3>
                    <p className="text-secondary-green font-semibold mb-2">Senior Adjudicator</p>
                    <p className="text-gray-600 text-sm">
                      Experienced educator and technology advocate who oversees competition evaluation 
                      processes. His significant contributions to Bright Light Academy demonstrate his 
                      commitment to advancing educational excellence through innovative approaches.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Evaluation Criteria */}
            <Card className="bg-white">
              <CardContent className="p-6">
                <h4 className="font-semibold mb-3 text-dark-text">Evaluation Criteria</h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-primary-blue rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Innovation and creativity in AI application
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-secondary-green rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Technical implementation and feasibility
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-accent-orange rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Educational impact and cultural relevance
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-primary-blue rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Presentation quality and documentation
                  </li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Competition Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {competitionFeatures.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-neutral-gray card-hover h-full text-center">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                    <feature.icon className="text-white" size={20} />
                  </div>
                  <h4 className="text-xl font-semibold mb-3">{feature.title}</h4>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Global Collaboration Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.2 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <Card className="bg-gradient-to-br from-primary-blue to-secondary-green text-white">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <Globe className="mx-auto mb-4" size={48} />
                <h3 className="text-3xl font-bold mb-4">Global Collaboration Open</h3>
                <p className="text-lg opacity-90 max-w-3xl mx-auto">
                  The Rex Igwe Innovation Award and lab initiatives welcome international students, 
                  educational institutions, and research partners. Together, we're building a global 
                  network for AI-powered educational innovation with worldwide impact.
                </p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Users className="text-white" size={24} />
                  </div>
                  <h4 className="font-semibold mb-2">International Students</h4>
                  <p className="text-sm opacity-90">Join our global community of innovators</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Award className="text-white" size={24} />
                  </div>
                  <h4 className="font-semibold mb-2">Educational Partners</h4>
                  <p className="text-sm opacity-90">Collaborate on research and innovation</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Globe className="text-white" size={24} />
                  </div>
                  <h4 className="font-semibold mb-2">Global Impact</h4>
                  <p className="text-sm opacity-90">Creating worldwide educational transformation</p>
                </div>
              </div>
              
              <div className="text-center mt-8">
                <Button className="bg-white text-primary-blue hover:bg-gray-100 font-semibold">
                  Join Global Initiative
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}